<?php
	$localhost = "127.0.0.1";
	$username = "root";
	$password = "";
	$dbname = "dvlatbl";

	$connect = new mysqli($localhost, $username, $password, $dbname);
	// $result1 = mysqli_query($connect, $query);
	// check connection
	if($connect -> connect_error) {
		die("Connection Failed : " . $connect->connect_error);
	} else {
		// echo "Successfully connected"
	}

?>