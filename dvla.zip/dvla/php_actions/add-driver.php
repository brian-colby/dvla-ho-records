<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	

	$firstName = $_POST['firstName'];
  	$lastName = $_POST['lastName']; 
  	$otherNames = $_POST['otherNames']; 
  	$phone = $_POST['phone']; 
  	$dateIssued = $_POST['dateIssued'];
  	$boxNumber = $_POST['boxNumber']; 
  	$dateTest = $_POST['dateTest']; 
  	$class = $_POST['class'];
  	$coc = $_POST['coc'];
  	$dateBirth = $_POST['dateBirth'];



	$sql = "INSERT INTO drivers_tbl (firstName, lastName, otherNames, phone, dateIssued, boxNumber, dateTest, class, coc, dateBirth) VALUES ('$firstName', '$lastName', '$otherNames', '$phone', '$dateIssued', '$boxNumber', '$dateTest', '$class', '$coc', '$dateBirth')";

	if($connect->query($sql) === TRUE) {
	 	$valid['success'] = true;
		$valid['messages'] = "Successfully Added";	
	} else {
	 	$valid['success'] = false;
	 	$valid['messages'] = "Error while adding the members";
	}
	 

	$connect->close();
	header('location: http://localhost:8080/dvla/admin-dashboard.php');
	echo '<script>alert("Successfully added")</script>';


	// echo json_encode($valid);
 
} // /if $_POST