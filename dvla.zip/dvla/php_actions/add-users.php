<?php 	

require_once 'core.php';

$valid['success'] = array('success' => false, 'messages' => array());

if($_POST) {	

	$username = $_POST['username'];
  	$password = $_POST['password'];
  	$password = md5($password); 
  	



	$sql = "INSERT INTO newUsers (username, password) VALUES ('$username', '$password')";

	if($connect->query($sql) === TRUE) {
	 	$valid['success'] = true;
		$valid['messages'] = "Successfully Added";	
	} else {
	 	$valid['success'] = false;
	 	$valid['messages'] = "Error while adding the members";
	}
	 

	$connect->close();
	header('location: http://localhost:8080/dvla/admin-settings.php');
	echo '<script>alert("Successfully added")</script>';


	// echo json_encode($valid);
 
} // /if $_POST