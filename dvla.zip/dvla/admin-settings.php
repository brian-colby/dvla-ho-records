
<?php 
require_once 'php_actions/core.php';
require_once 'includes/admin-header.php';
?>
<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start --><!-- Developed by Brian Colby Adjah -- 0576115440 -->

        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Admin Dashboard</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard-analytics.php"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Admin Settings</a></li>
                        </ul>
                    </div>
                </div>
            </div><!-- Developed by Brian Colby Adjah -- 0576115440 -->

        </div>
        <!-- [ breadcrumb ] end -->

        <div class="row">
        	<div class="col-sm-6">
	        	<div class="card">
	        		<div class="card-body">
	        			<div class="card-header">
	        				<h5>Security Settings</h5>
	        			</div>
	        			<div class="card-body">
	        				<form action="php_actions/admin-change-password.php" method="post" class="form-horizontal" id="changePasswordForm">
									<div class="changePasswordMessages"></div>

								<div class="form-group">
								    <div class="col-sm-12">
								      <input type="password" class="form-control" id="password" name="password" placeholder="Current Password">
								    </div>
								  </div>

								  <div class="form-group">
								    <div class="col-sm-12">
								      <input type="password" class="form-control" id="npassword" name="npassword" placeholder="New Password" required="" minlength="8">
								    </div>
								  </div>

								  <div class="form-group">
								    <div class="col-sm-12">
								      <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Confirm Password" required="" minlength="8">
								    </div>
								  </div><!-- Developed by Brian Colby Adjah -- 0576115440 -->


								  <div class="form-group">
								    <div class="col-sm-offset-2 col-sm-10">
								    	<input type="hidden" name="user_id" id="user_id" value="<?php echo $result['user_id'] ?>" /> 
								      <button type="submit" class="btn btn-primary"> <i class="feather mr-2 icon-check-circle"></i> Save Changes </button>
								      
								    </div>
								  </div>
								</form>
	        			</div>
	        		</div>
	        	</div>
	        </div>
	        <!-- here is the adding new users -->
	        <div class="col-sm-6">
	        	<div class="card">
	        		<div class="card-header">
	        			<h5>Users Table</h5>
	        			<div id="exampleModalLive" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLiveLabel" aria-hidden="true"><!-- Developed by Brian Colby Adjah -- 0576115440 -->

							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" id="exampleModalLiveLabel"><i class="feather icon-plus"> </i> Add New User</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									</div>
									<div class="modal-body">
										<form class="form-horizontal" id="submitUsersForm" action="php_actions/add-users.php" method="POST">
											<div class="form-row">
											    <div class="form-group col-md-12">
											    	<label for="username">Username</label>
											      <input type="text" class="form-control" id="username" name="username" placeholder="" required="">
											    </div>
											</div>
											
										  	<div class="form-row">
											    <div class="form-group col-sm-12">
											    	<label for="password">Password</label>
											      <input type="text" class="form-control" id="password" name="password" placeholder="">
											    </div>
										  	</div>
										  	
											<div class="modal-footer">
												<button type="button" class="btn  btn-danger" data-dismiss="modal">Close</button>
												<button type="submit" class="btn  btn-primary" id="createUsersBtn" data-loading-text="Loading..." autocomplete="off" data-bs-dismiss="alert" aria-label="Close">Add User</button>
											</div>
										</form>
									</div>
								</div>
							</div><!-- Developed by Brian Colby Adjah -- 0576115440 -->

						</div>
	        			<button style="float:right;" type="button" class="btn btn-success btn-sm btn-round has-ripple" data-toggle="modal" data-target="#exampleModalLive"><i class="feather icon-user-plus"> </i> Add New User</button>
	        		</div>

	        		<div class="card-body">
                        <div class="dt-responsive table-responsive">
                            <table id="simpletable" class="table table-striped table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th>Username</th>
                                        <th>Password</th>
                                        <!-- <th>Actions</th> -->
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
                                	include 'php_actions/db_connect.php';
                                	$sql = "SELECT * FROM newUsers";
                                	$result = $connect-> query($sql);

                                	if ($result-> num_rows > 0) {
                                		while ($row = $result-> fetch_assoc()){
                                			echo "<tr><td>" . $row["username"] . "</td><td>" . $row["password"] ."</td><tr>";
                                		}
                                		echo "</table>";
                                	} else {
                                		echo "0 results";
                                	}
                                	$connect-> close();
                                	?>
                                	</tbody>
                            </table>
                        </div>
                    </div>
                </div>
	        	</div><!-- Developed by Brian Colby Adjah -- 0576115440 -->

	        </div>	
        </div>

    </div>
</div>    





<?php require_once 'includes/admin-footer.php';