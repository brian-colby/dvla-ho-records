

<?php 
require_once 'php_actions/core.php';
require_once 'includes/admin-header.php';
?>
<?php
include 'php_actions/db_connect.php';

$sql = "SELECT * FROM newUsers ";
$query = $connect->query($sql);
$countUsers = $query->num_rows;

$sqlDrivers = "SELECT * FROM drivers_tbl";
$tenantQuery = $connect->query($sqlDrivers);
$countDrivers = $tenantQuery->num_rows;


$connect->close();

?><!-- Developed by Brian Colby Adjah -- 0576115440 -->

<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Admin Dashboard</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard-analytics.php"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Drivers</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->
        <div class="row">
            <!-- customar project  start -->
            <div class="col-xl-6 col-md-6"><!-- Developed by Brian Colby Adjah -- 0576115440 -->

                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center m-l-0">
                            <div class="col-auto">
                                <i class="fas fa-user-tie f-36 text-c-blue"></i>
                            </div>
                            <div class="col-auto">
                                <h6 class="text-muted m-b-10">Total Number Of Entries</h6>
                                <h2 class="m-b-0"><?php echo $countDrivers; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-6 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row align-items-center m-l-0">
                            <div class="col-auto">
                                <i class="fas fa-users f-36 text-c-blue"></i>
                            </div>
                            <div class="col-auto">
                                <h6 class="text-muted m-b-10">Total Number Of Users</h6>
                                <h2 class="m-b-0"><?php echo $countUsers; ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ Main Content ] start -->
        <div class="row">
            <!-- Zero config table start -->
            <div class="col-sm-12"><!-- Developed by Brian Colby Adjah -- 0576115440 -->

                <div class="card">
                    <div class="card-header">
                        <h5>Driver's Data</h5>
                        <div id="exampleModalLive" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="exampleModalLiveLabel" aria-hidden="true">
							<div class="modal-dialog modal-lg" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" id="exampleModalLiveLabel"><i class="feather icon-plus"> </i> Add Driver</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									</div>
									<div class="modal-body">
										<form class="form-horizontal" id="submitTenantForm" action="php_actions/add-driver.php" method="POST">
											<div class="form-row">
											    <div class="form-group col-md-6">
											    	<label for="firstName">First Name <span style="color: red;">*</span></label>
											      <input type="text" class="form-control" id="firstName" name="firstName" placeholder="" required="">
											    </div>
											    <div class="form-group col-md-6">
											    	<label for="lastName">Last Name <span style="color: red;">*</span></label>
											      <input type="text" class="form-control" id="lastName" name="lastName" placeholder="" required="">
											    </div>
											</div>
											
										  	<div class="form-row">
											    <div class="form-group col-sm-6">
											    	<label for="otherNames">Other Names</label>
											      <input type="text" class="form-control" id="otherNames" name="otherNames" placeholder="">
											    </div>
											    <div class="form-group col-sm-6">
											    	<label for="phone">Contact Number <span style="color: red;">*</span></label>
											      <input type="text" class="form-control" id="phone" name="phone" placeholder="" required="">
											    </div>
										  	</div>
										  	<div class="form-row">
											    <div class="form-group col-sm-6">
											    	<label for="dateIssued">Date Of Issue <span style="color: red;">*</span></label>
											      <input type="date" class="form-control" id="dateIssued" name="dateIssued" placeholder="" required="">
											    </div>
											    <div class="form-group col-sm-6">
											    	<label for="boxNumber">Box Number</label>
											      <input type="text" class="form-control" id="boxNumber" name="boxNumber" placeholder="P.O Box">
											    </div>
										  	</div>
										  	<div class="form-row">
											    <div class="form-group col-sm-6">
											    	<label for="dateTest">Date Of Test <span style="color: red;">*</span></label>
											      <input type="date" class="form-control" id="dateTest" name="dateTest" placeholder="" required="">
											    </div>
											   <!--  <div class="form-group col-sm-6">
											    	<label for="class">Licence Class</label>
											      <input type="text" class="form-control" id="class" name="class" placeholder="Class B" required="">
											    </div> -->

											    <div class="form-group col-md-6">
		                                        <label for="class">Licence Class  <span style="color: red;">*</span></label>
		                                        <select class="form-control" id="class" name="class" placeholder="">
		                                        	<option disabled=""> ~~ Select Class Type ~~</option>
		                                            <option value="A">A</option>
		                                            <option selected="" value="B">B</option>
		                                            <option value="C">C</option>
		                                            <option value="D">D</option>
		                                            <option value="E">E</option>
		                                            <option value="F">F</option>
		                                            <option value="AB">AB</option>
		                                            <option value="AE">AE</option>
		                                            <option value="BE">BE</option>
		                                            <option value="ABE">ABE</option>
		                                            <option value="AC">AC</option>
		                                            <option value="AF">AF</option>
		                                            <option value="CE">CE</option>
		                                            <option value="AD">AD</option>
		                                            <option value="EF">EF</option>
		                                            <option value="DE">DE</option>
		                                            <option value="ADE">ADE</option>
		                                            <option value="AEF">AEF</option>
		                                            <option value="ACE">ACE</option>
		                                        </select><!-- Developed by Brian Colby Adjah -- 0576115440 -->

		                                    </div>
										  	</div>
										  	<div class="form-row">
											    <div class="form-group col-sm-6">
											    	<label for="coc">CoC <span style="color: red;">*</span></label>
											      <input type="text" class="form-control" id="coc" name="coc" placeholder="CoC" required="">
											    </div>
											    <div class="form-group col-sm-6">
											    	<label for="dateBirth">Date Of Birth <span style="color: red;">*</span></label>
											      <input type="date" class="form-control" id="dateBirth" name="dateBirth" placeholder="Date Of Birth" required="">
											    </div>
										  	</div>
										  	
											<div class="modal-footer">
												<button type="button" class="btn  btn-danger" data-dismiss="modal">Close</button>
												<button type="submit" class="btn  btn-primary" id="createTenantBtn" data-loading-text="Loading..." autocomplete="off" data-bs-dismiss="alert" aria-label="Close">Save changes</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
						<!-- <button type="button" class="btn  btn-primary" data-toggle="modal" data-target="#exampleModalLive">Launch demo modal</button> -->
                        <button style="float:right;" type="button" class="btn btn-success btn-sm btn-round has-ripple" data-toggle="modal" data-target="#exampleModalLive"><i class="feather icon-user-plus"> </i> Add New Driver</button>
                    </div>
                    <div class="card-body">
                        <div class="dt-responsive table-responsive">
                            <table id="simpletable" class="table table-striped table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Other Names</th>
                                        <th>Contact</th>
                                        <th>Date Of Issue</th>
                                        <th>Box Number</th>
                                        <th>Date Of Test</th>
                                        <th>Licence Class</th>
                                        <th>CoC</th>
                                        <th>Date Of Birth</th>
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php 
                                	include 'php_actions/db_connect.php';
                                	$sql = "SELECT * FROM drivers_tbl";
                                	$result = $connect-> query($sql);

                                	if ($result-> num_rows > 0) {
                                		while ($row = $result-> fetch_assoc()){
                                			echo "<tr><td>" . $row["firstName"] . "</td><td>" . $row["lastName"] ."</td><td>" . $row["otherNames"] ."</td><td>" . $row["phone"] ."</td><td>" . $row["dateIssued"] ."</td><td>" . $row["boxNumber"] ."</td><td>" . $row["dateTest"] ."</td><td>" . $row["class"] ."</td><td>" . $row["coc"] ."</td><td>" . $row["dateBirth"] . "</td></tr>";
                                		}
                                		echo "</table>";
                                	} else {
                                		echo "0 results";
                                	}
                                	$connect-> close();
                                	?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Zero config table end -->

        </div>










        <?php require_once 'includes/admin-footer.php'; ?>      