<?php 
require_once 'php_actions/db_connect.php';
session_start();

if(isset($_SESSION['userId'])) {
	header('location: http://localhost:8080/dvla/admin-dashboard.php');	
}

$errors = array();

if($_POST) {		

	$username = $_POST['username'];
	$password = $_POST['password'];

	if(empty($username) || empty($password)) {
		if($username == "") {
			$errors[] = "Username is required";
		} 

		if($password == "") {
			$errors[] = "Password is required";
		}
	} else {
		$sql = "SELECT * FROM users WHERE username = '$username'";
		$result = $connect->query($sql);

		if($result->num_rows == 1) {
			$password = md5($password);
			// exists
			$mainSql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
			$mainResult = $connect->query($mainSql);

			if($mainResult->num_rows == 1) {
				$value = $mainResult->fetch_assoc();
				$user_id = $value['user_id'];

				// set session
				$_SESSION['userId'] = $user_id;

				header('location: http://localhost:8080/dvla/admin-dashboard.php');
				$message[] = "Login Success!";
			} else{
				
				$errors[] = "Incorrect username/password combination";
			} // /else
		} else {		
			$errors[] = "Username doesnot exists";		
		} // /else
	} // /else not empty username // password
	
} // /if $_POST
?>

<!DOCTYPE html>
<html lang="en">

<head>

	<title>DVLA Records - Admin Login</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="description" content="" />
	<meta name="keywords" content="">
	<meta name="author" content="Phoenixcoded" />
	<!-- Favicon icon -->
	<link rel="icon" href="assets/images/dvla.jpg" type="image/x-icon">
<!-- Developed by Brian Colby Adjah -- 0576115440 -->

	<!-- vendor css -->
	<link rel="stylesheet" href="assets/css/style.css">
	
	
<!-- Developed by Brian Colby Adjah -- 0576115440 -->


</head>

<!-- [ signin-img ] start -->
<div class="auth-wrapper align-items-stretch aut-bg-img">
	<div class="flex-grow-1">
		<div class="h-100 d-md-flex align-items-center auth-side-img">
			<div class="col-sm-10 auth-content w-auto">
				<h1 class="text-white my-4">Admin, Welcome Back!</h1>
			</div>
		</div><!-- Developed by Brian Colby Adjah -- 0576115440 -->

		<div class="auth-side-form">
			<div class=" auth-content">
				<a  href="http://localhost:8080/dvla/index.php"><img src="assets/images/dvla.jpg" style="width: 6em;" alt="" class="img-fluid mb-1"></a>
				<h3 class="mb-4 f-w-400">Admin Signin</h3>
				<div class="messages">
							<?php if($errors) {
								foreach ($errors as $key => $value) {
									echo '<div class="alert alert-danger" role="alert">
									<i class="glyphicon glyphicon-exclamation-sign"></i>
									'.$value.'</div>';										
									}
								} ?>
						</div>
				<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" >
				<div class="form-group mb-3">
					<label class="floating-label" for="username">Username</label>
					<input type="text" class="form-control" id="username" name="username" placeholder="">
				</div>
				<div class="form-group mb-4">
					<label class="floating-label" for="Password">Password</label>
					<input type="password" class="form-control" id="Password" name="password" placeholder="">
				</div>
				<button type="submit" class="btn btn-block btn-primary mb-4">Log In</button>
				<div class="text-center">
					<!-- <p class="mb-2 mt-4 text-muted">Forgot password? <a href="auth-reset-password-img-side.html" class="f-w-400">Reset</a></p> -->
					<p class="mb-0 text-muted">You are not an Admin? <a href="user-login.php" class="f-w-400">User Login</a></p>
				</div>
				
				</form>
			</div>
		</div>
	</div>
</div>
<!-- [ signin-img ] end -->

<!-- Required Js -->
<script src="assets/js/vendor-all.min.js"></script>
<script src="assets/js/plugins/bootstrap.min.js"></script>
<script src="assets/js/ripple.js"></script>
<script src="assets/js/pcoded.min.js"></script>

<!-- Developed by Brian Colby Adjah -- 0576115440 -->


</body>

</html><!-- Developed by Brian Colby Adjah -- 0576115440 -->
<!-- Developed by Brian Colby Adjah -- 0576115440 -->
