
<?php 
require_once 'php_actions/core.php';
require_once 'includes/user-header.php';
?>
<!-- [ Main Content ] start -->
<!-- Developed by Brian Colby Adjah -- 0576115440 -->

<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">User Dashboard</h5>
                        </div><!-- Developed by Brian Colby Adjah -- 0576115440 -->

                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard-analytics.php"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">User Settings</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->

        <div class="row">
        	<div class="col-sm-12">
	        	<div class="card">
	        		<div class="card-body">
	        			<div class="card-header">
	        				<h5>Security Settings</h5>
	        			</div>
	        			<div class="card-body">
	        				<form action="php_actions/admin-change-password.php" method="post" class="form-horizontal" id="changePasswordForm">
									<div class="changePasswordMessages"></div>

								<div class="form-group">
								    <div class="col-sm-12">
								      <input type="password" class="form-control" id="password" name="password" placeholder="Current Password">
								    </div>
								  </div>

								  <div class="form-group">
								    <div class="col-sm-12">
								      <input type="password" class="form-control" id="npassword" name="npassword" placeholder="New Password" required="" minlength="8">
								    </div>
								  </div><!-- Developed by Brian Colby Adjah -- 0576115440 -->


								  <div class="form-group">
								    <div class="col-sm-12">
								      <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Confirm Password" required="" minlength="8">
								    </div>
								  </div>

								  <div class="form-group">
								    <div class="col-sm-offset-2 col-sm-10">
								    	<input type="hidden" name="user_id" id="user_id" value="<?php echo $result['user_id'] ?>" /> 
								      <button type="submit" class="btn btn-primary"> <i class="feather mr-2 icon-check-circle"></i> Save Changes </button>
								      
								    </div>
								  </div>
								</form>
	        			</div>
	        		</div>
	        	</div><!-- Developed by Brian Colby Adjah -- 0576115440 -->

	        </div>
	        </div>	
        </div>

    </div>
</div>    





<?php require_once 'includes/user-footer.php';