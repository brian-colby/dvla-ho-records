<?php 
require_once 'php_actions/core.php';
require_once 'includes/admin-header.php';
?>

<!-- [ Main Content ] start -->
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ breadcrumb ] start -->
        <div class="page-header"><!-- Developed by Brian Colby Adjah -- 0576115440 -->

            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Admin Dashboard</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard-analytics.php"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="#!">Transactions</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- [ breadcrumb ] end -->

<!-- [ Main Content ] start -->
        <div class="row"><!-- Developed by Brian Colby Adjah -- 0576115440 -->

            <!-- Zero config table start -->
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <h5>Transactions Data</h5>
                    </div>
                    <div class="card-body">
                        <div class="dt-responsive table-responsive">
                            <table id="simpletable" class="table table-striped table-bordered nowrap">
                                <thead>
                                    <tr>
                                        <th>Tenant Name</th>
                                        <th>Amount Paid</th>
                                        <th>Contact Number</th>
                                        <th>Transaction ID</th>
                                        <th>Tenant Email</th>
                                        <th>Date Of Transaction</th>
                                    </tr>
                                </thead>
                                <!-- Developed by Brian Colby Adjah -- 0576115440 -->

                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Zero config table end -->

        </div>


<!-- Developed by Brian Colby Adjah -- 0576115440 -->




        <?php require_once 'includes/admin-footer.php'; ?>     