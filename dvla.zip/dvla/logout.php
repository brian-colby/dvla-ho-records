<?php 

require_once 'php_actions/core.php';

// remove all session variables
session_unset(); 

// destroy the session 
session_destroy(); 

header('location: http://localhost:8080/dvla/index.php');

?>